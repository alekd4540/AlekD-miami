# AlekD Architectural Design — Miami Beach Website

This is a multi-page portfolio website for **AlekD Architectural Design**, based in Miami Beach, Florida.

## 📁 Project Structure
```
alekd-miami/
├── index.html
├── work.html
├── project-beachfront-villa.html
├── project-ocean-drive-offices.html
├── project-art-deco-gallery.html
├── services.html
├── studio.html
├── contact.html
├── styles.css
├── script.js
└── netlify.toml
```

## 🚀 Deployment

### Option 1: Netlify (Recommended)
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag & drop the `alekd-miami` folder (or the ZIP).
3. Netlify will auto-deploy your site.
4. The contact form will work automatically because of the built-in Netlify form handling.

### Option 2: Vercel
1. Install [Vercel CLI](https://vercel.com/docs/cli) or use the Vercel dashboard.
2. Create a new project and import the `alekd-miami` folder.
3. Deploy → Your site will be live on a Vercel URL.

### Option 3: GitHub Pages
1. Create a GitHub repository.
2. Upload the contents of the `alekd-miami` folder.
3. In repository settings → Enable GitHub Pages (branch: `main`, folder: `/root`).
4. Your site will be live at `https://yourusername.github.io/repository-name`.

## 📝 Notes
- Replace placeholder images with your own project photos.
- Update `contact.html` with your real email, phone, and address.
- Styling is controlled in `styles.css`.
- The footer year updates automatically via `script.js`.

---
✨ Built for AlekD Architectural Design — Miami Beach, FL
